#include "network_settings.h"

network_settings::network_settings()
{

}

network_settings::~network_settings()
{

}
