#ifndef NETWORK_SETTINGS_H
#define NETWORK_SETTINGS_H


#include <QNetworkInterface>
#include <QNetworkAddressEntry>

class network_settings
{
public:
    network_settings();
    ~network_settings();
};

#endif // NETWORK_SETTINGS_H
